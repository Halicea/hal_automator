# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file '/Users/kostamihajlov/MyProjects/hal_automator/automator_project/utils/qtUi/configwindow.ui'
#
# Created: Sun Jan  6 00:43:02 2013
#      by: pyside-uic 0.2.13 running on PySide 1.1.0
#
# WARNING! All changes made in this file will be lost!

from PySide import QtCore, QtGui

class Ui_ConfigWindow(object):
    def setupUi(self, ConfigWindow):
        ConfigWindow.setObjectName("ConfigWindow")
        ConfigWindow.resize(800, 600)
        ConfigWindow.setDockOptions(QtGui.QMainWindow.AllowTabbedDocks|QtGui.QMainWindow.AnimatedDocks)
        ConfigWindow.setUnifiedTitleAndToolBarOnMac(True)
        self.centralwidget = QtGui.QWidget(ConfigWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.verticalLayout_2 = QtGui.QVBoxLayout(self.centralwidget)
        self.verticalLayout_2.setObjectName("verticalLayout_2")
        self.ltv_content = QtGui.QVBoxLayout()
        self.ltv_content.setObjectName("ltv_content")
        self.verticalLayout_2.addLayout(self.ltv_content)
        ConfigWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtGui.QMenuBar()
        self.menubar.setGeometry(QtCore.QRect(0, 0, 800, 22))
        self.menubar.setObjectName("menubar")
        self.menuFile = QtGui.QMenu(self.menubar)
        self.menuFile.setObjectName("menuFile")
        self.menuEdit = QtGui.QMenu(self.menubar)
        self.menuEdit.setObjectName("menuEdit")
        self.menuHelp = QtGui.QMenu(self.menubar)
        self.menuHelp.setObjectName("menuHelp")
        ConfigWindow.setMenuBar(self.menubar)
        self.statusbar = QtGui.QStatusBar(ConfigWindow)
        self.statusbar.setObjectName("statusbar")
        ConfigWindow.setStatusBar(self.statusbar)
        self.actionSave = QtGui.QAction(ConfigWindow)
        self.actionSave.setObjectName("actionSave")
        self.actionRun = QtGui.QAction(ConfigWindow)
        self.actionRun.setObjectName("actionRun")
        self.actionCopy = QtGui.QAction(ConfigWindow)
        self.actionCopy.setObjectName("actionCopy")
        self.actionCopy_2 = QtGui.QAction(ConfigWindow)
        self.actionCopy_2.setObjectName("actionCopy_2")
        self.actionPaste = QtGui.QAction(ConfigWindow)
        self.actionPaste.setObjectName("actionPaste")
        self.actionAbout = QtGui.QAction(ConfigWindow)
        self.actionAbout.setObjectName("actionAbout")
        self.actionOpen = QtGui.QAction(ConfigWindow)
        self.actionOpen.setObjectName("actionOpen")
        self.actionRecent_Configurations = QtGui.QAction(ConfigWindow)
        self.actionRecent_Configurations.setObjectName("actionRecent_Configurations")
        self.menuFile.addAction(self.actionSave)
        self.menuFile.addAction(self.actionRun)
        self.menuFile.addAction(self.actionOpen)
        self.menuFile.addAction(self.actionRecent_Configurations)
        self.menuEdit.addAction(self.actionCopy_2)
        self.menuEdit.addAction(self.actionPaste)
        self.menuHelp.addAction(self.actionAbout)
        self.menubar.addAction(self.menuFile.menuAction())
        self.menubar.addAction(self.menuEdit.menuAction())
        self.menubar.addAction(self.menuHelp.menuAction())

        self.retranslateUi(ConfigWindow)
        QtCore.QMetaObject.connectSlotsByName(ConfigWindow)

    def retranslateUi(self, ConfigWindow):
        ConfigWindow.setWindowTitle(QtGui.QApplication.translate("ConfigWindow", "MainWindow", None, QtGui.QApplication.UnicodeUTF8))
        self.menuFile.setTitle(QtGui.QApplication.translate("ConfigWindow", "File", None, QtGui.QApplication.UnicodeUTF8))
        self.menuEdit.setTitle(QtGui.QApplication.translate("ConfigWindow", "Edit", None, QtGui.QApplication.UnicodeUTF8))
        self.menuHelp.setTitle(QtGui.QApplication.translate("ConfigWindow", "Help", None, QtGui.QApplication.UnicodeUTF8))
        self.actionSave.setText(QtGui.QApplication.translate("ConfigWindow", "Save", None, QtGui.QApplication.UnicodeUTF8))
        self.actionRun.setText(QtGui.QApplication.translate("ConfigWindow", "Run", None, QtGui.QApplication.UnicodeUTF8))
        self.actionCopy.setText(QtGui.QApplication.translate("ConfigWindow", "Copy", None, QtGui.QApplication.UnicodeUTF8))
        self.actionCopy_2.setText(QtGui.QApplication.translate("ConfigWindow", "Copy", None, QtGui.QApplication.UnicodeUTF8))
        self.actionPaste.setText(QtGui.QApplication.translate("ConfigWindow", "Paste", None, QtGui.QApplication.UnicodeUTF8))
        self.actionAbout.setText(QtGui.QApplication.translate("ConfigWindow", "About", None, QtGui.QApplication.UnicodeUTF8))
        self.actionOpen.setText(QtGui.QApplication.translate("ConfigWindow", "Open", None, QtGui.QApplication.UnicodeUTF8))
        self.actionRecent_Configurations.setText(QtGui.QApplication.translate("ConfigWindow", "Recent Configurations", None, QtGui.QApplication.UnicodeUTF8))

