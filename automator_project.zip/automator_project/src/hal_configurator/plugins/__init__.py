from replace_text import ReplaceText as replace_text
from replace_from_url import ReplaceFromUrl as replace_from_url
from add_android_resource import AddAndroidResource as add_android_resource
from add_ios_resource import AddIosResource as add_ios_resource
from shell_script import ShellScript as shell_script
from delete_file import DeleteFile
__all__ = ["replace_text", "replace_from_url", "add_android_resource", "add_ios_resource", "shell_script",  "delete_file"]
