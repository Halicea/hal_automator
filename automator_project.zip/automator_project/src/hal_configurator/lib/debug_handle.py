'''
Created on Feb 8, 2013

@author: kostamihajlov
'''

class DebugHandle(object):
  
  def __init__(self):
    pass
  
  def continueExectution(self):
    pass

    
  
  
