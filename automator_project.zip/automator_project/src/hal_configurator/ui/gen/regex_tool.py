# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file '/Users/kostamihajlov/MyProjects/hal_automator/automator_project/utils/qtUi/regex_tool.ui'
#
# Created: Sun Jan  6 00:43:02 2013
#      by: pyside-uic 0.2.13 running on PySide 1.1.0
#
# WARNING! All changes made in this file will be lost!

from PySide import QtCore, QtGui

class Ui_RegexTool(object):
    def setupUi(self, RegexTool):
        RegexTool.setObjectName("RegexTool")
        RegexTool.resize(593, 525)
        self.verticalLayout_3 = QtGui.QVBoxLayout(RegexTool)
        self.verticalLayout_3.setObjectName("verticalLayout_3")
        self.gridLayout = QtGui.QGridLayout()
        self.gridLayout.setObjectName("gridLayout")
        self.txtRegex = QtGui.QLineEdit(RegexTool)
        self.txtRegex.setObjectName("txtRegex")
        self.gridLayout.addWidget(self.txtRegex, 1, 1, 1, 1)
        self.btnRun = QtGui.QPushButton(RegexTool)
        self.btnRun.setObjectName("btnRun")
        self.gridLayout.addWidget(self.btnRun, 1, 2, 1, 1)
        self.txtReplaceWith = QtGui.QLineEdit(RegexTool)
        self.txtReplaceWith.setObjectName("txtReplaceWith")
        self.gridLayout.addWidget(self.txtReplaceWith, 2, 1, 1, 1)
        self.label_3 = QtGui.QLabel(RegexTool)
        self.label_3.setObjectName("label_3")
        self.gridLayout.addWidget(self.label_3, 1, 0, 1, 1)
        self.label_4 = QtGui.QLabel(RegexTool)
        self.label_4.setObjectName("label_4")
        self.gridLayout.addWidget(self.label_4, 2, 0, 1, 1)
        self.verticalLayout_3.addLayout(self.gridLayout)
        self.splitter = QtGui.QSplitter(RegexTool)
        self.splitter.setOrientation(QtCore.Qt.Vertical)
        self.splitter.setObjectName("splitter")
        self.widget = QtGui.QWidget(self.splitter)
        self.widget.setObjectName("widget")
        self.verticalLayout_2 = QtGui.QVBoxLayout(self.widget)
        self.verticalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout_2.setObjectName("verticalLayout_2")
        self.label = QtGui.QLabel(self.widget)
        self.label.setObjectName("label")
        self.verticalLayout_2.addWidget(self.label)
        self.txtTest = QtGui.QPlainTextEdit(self.widget)
        self.txtTest.setObjectName("txtTest")
        self.verticalLayout_2.addWidget(self.txtTest)
        self.widget1 = QtGui.QWidget(self.splitter)
        self.widget1.setObjectName("widget1")
        self.verticalLayout = QtGui.QVBoxLayout(self.widget1)
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout.setObjectName("verticalLayout")
        self.label_2 = QtGui.QLabel(self.widget1)
        self.label_2.setObjectName("label_2")
        self.verticalLayout.addWidget(self.label_2)
        self.txtResult = QtGui.QPlainTextEdit(self.widget1)
        self.txtResult.setObjectName("txtResult")
        self.verticalLayout.addWidget(self.txtResult)
        self.verticalLayout_3.addWidget(self.splitter)

        self.retranslateUi(RegexTool)
        QtCore.QMetaObject.connectSlotsByName(RegexTool)

    def retranslateUi(self, RegexTool):
        RegexTool.setWindowTitle(QtGui.QApplication.translate("RegexTool", "Regex Test Tool", None, QtGui.QApplication.UnicodeUTF8))
        self.btnRun.setText(QtGui.QApplication.translate("RegexTool", "Test", None, QtGui.QApplication.UnicodeUTF8))
        self.label_3.setText(QtGui.QApplication.translate("RegexTool", "Regex:", None, QtGui.QApplication.UnicodeUTF8))
        self.label_4.setText(QtGui.QApplication.translate("RegexTool", "Replace With:", None, QtGui.QApplication.UnicodeUTF8))
        self.label.setText(QtGui.QApplication.translate("RegexTool", "Test Against:", None, QtGui.QApplication.UnicodeUTF8))
        self.label_2.setText(QtGui.QApplication.translate("RegexTool", "Result:", None, QtGui.QApplication.UnicodeUTF8))

